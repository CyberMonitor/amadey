<?php
    session_start();
    if (!isset($_SESSION['username']))
    {
        header('Location: login.php');
        die();
    }
?>

<!DOCTYPE html> 
<html>
    <head>
        <link rel="shortcut icon" type="image/png" href="img/favicon.png" />
        <link rel="stylesheet" type="text/css" href="css/jquery.fancybox.min.css" />
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" />
        
        <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
        <script type="text/javascript" src="js/jquery.fancybox.min.js"></script>
    </head>

    <body>
        <?php
            $type = 'loader';
            include('nav_bar.php');

            if (!empty($_POST['loader_url']) && !empty($_POST['task_name']))
            {
                $db = new SQLite3('info/loader.db');
                $tmp_res = $db->query("SELECT * from main WHERE name='{$_POST['task_name']}'")->fetchArray();
                if (!$tmp_res)
                {
                    $db->exec("INSERT INTO main (name, link) VALUES ('{$_POST['task_name']}', '{$_POST['loader_url']}')");
                }
                $db->close();
            }
            else if (!empty($_GET['delete_name']))
            {
                $db = new SQLite3('info/loader.db');
                $db->exec("DELETE from main WHERE name='{$_GET['delete_name']}'");
                $db->close();
            }
        ?>

        <div class="col-md-9">

            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Task name</th>
                        <th scope="col">File URL</th>
                        <th scope="col"></th>
                    </tr>
                </thead>
                
                <tbody id="main_items">
                    <?php
                        $db = new SQLite3('info/loader.db');
                        $results = $db->query('SELECT * from main');
                        while ($row = $results->fetchArray())
                        {
                            echo "<tr class=\"table-item\">";
                            echo "<td>{$row['name']}</td>";
                            echo "<td>{$row['link']}</td>";
                            echo "<td><a href=\"loader.php?delete_name={$row['name']}\" class=\"table-button\"><i class=\"fas fa-trash-alt\"></i></a></td>";
                            echo "</tr>";
                        }
                        $db->close();
                    ?>
                </tbody>
            </table>


            <form id="loader_add">
                    <p class="content-subheading select-block">
                        Task name: <input name="task_name" />
                    </p>

                    <p class="content-subheading select-block">
                        File URL: <input name="loader_url" />
                    </p>

                    <center>
                        <button type="submit" style="margin-top:30px;width:200px;height:25px">Add task</button>
                    </center>
            </form>

            <script>
                $('#loader_add').submit(function (event) {
                    event.preventDefault();
                  var post_data = $('#loader_add').serialize();
                  $.post('loader.php', post_data, function(data) {
                      $('#notification').show();
                      location.reload();
                  });
                });
            </script>
        </div>

    </body>
</html>