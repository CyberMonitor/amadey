<?php
define('DB_AES_PWD', 'cdsqstwPd4wppx2W');
define('DB_AES_IV', 'qiqFERGX0u1V9w9D');
include('AES.php');
$login = 'god';
$password = 'AuschwitzN732015';
$encryption_key = 'a4g8ivg4x2MRKkHrpUVW0NBf1zyx56e';

function getClientIp()
{
    $client_ip = '';
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR']) && filter_var($_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
        $client_ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else $client_ip = $_SERVER['REMOTE_ADDR'];
    return $client_ip;
}

function getOsName($os_id)
{
    $os_version = '';
    switch ($os_id)
    {
        case 0: $os_version = 'UNKNOWN'; break;
        case 1: $os_version = 'XP'; break;
        case 2: $os_version = 'SERVER_2003'; break;
        case 3: $os_version = 'VISTA'; break;
        case 4: $os_version = 'SERVER_2008'; break;
        case 5: $os_version = 'WIN7'; break;
        case 6: $os_version = 'SERVER_2008_R2'; break;
        case 7: $os_version = 'WIN8'; break;
        case 8: $os_version = 'SERVER_2012'; break;
        case 9: $os_version = 'WIN8.1'; break;
        case 10: $os_version = 'SERVER_2012_R2'; break;
        case 11: $os_version = 'WIN10'; break;
        case 12: $os_version = 'SERVER_2016'; break;
        default: break;
    }
    return $os_version;
}
?>
