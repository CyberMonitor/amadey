<?php
$base64 = base64_encode(file_get_contents($_GET['_f']));
print_r($base64);
?>